#!/bin/sh
/home/pedro/android-sdks/platform-tools/adb connect 192.168.56.3
echo done
/home/pedro/android-sdks/platform-tools/adb devices -l
sleep 5

