/** Automatically generated file. DO NOT MODIFY */
package android.hci.extractor.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}